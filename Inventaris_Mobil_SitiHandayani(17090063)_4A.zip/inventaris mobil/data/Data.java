package data;

public class Data {
    private String noken;
    private String merk;
    private String type;
    private String pabrikan;
    private int tahun;
    private int daya;
    private String bbm;
    private int harga;

    public Data(String noken, String merk, String type, String pabrikan, int tahun, int daya, String bbm, int harga) {
        this.noken = noken;
        this.merk = merk;
        this.type = type;
        this.pabrikan = pabrikan;
        this.tahun = tahun;
        this.daya = daya;
        this.bbm = bbm;
        this.harga = harga;
    }

    @Override
    public boolean equals(Object o) {
        Data dt = (Data) o;
        return noken.equals(dt.getNoken());
    }

    public String getNoken() {
        return noken;
    }

    public void setNoken(String noken) {
        this.noken = noken;
    }

    public String getMerk() {
        return merk;
    }

    public void setMerk(String merk) {
        this.merk = merk;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPabrikan() {
        return pabrikan;
    }

    public void setPabrikan(String pabrikan) {
        this.pabrikan = pabrikan;
    }

    public int getTahun() {
        return tahun;
    }

    public void setTahun(int tahun) {
        this.tahun = tahun;
    }

    public int getDaya() {
        return daya;
    }

    public void setDaya(int daya) {
        this.daya = daya;
    }

    public String getBbm() {
        return bbm;
    }

    public void setBbm(String bbm) {
        this.bbm = bbm;
    }

    public int getHarga() {
        return harga;
    }

    public void setHarga(int harga) {
        this.harga = harga;
    }
}