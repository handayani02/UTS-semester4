import data.Data;
import proses.Operasi;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Aplikasi {
    private static Scanner scn;
    private static Operasi op;

    public static void main(String args[]){
        int m;
        scn = new Scanner(System.in);
        op = new Operasi();


        do {
            menu();
            try {
                scn = new Scanner(System.in);
                m = scn.nextInt();
                pilih(m);
            }catch (InputMismatchException e){
                System.out.println("Masukan pilihan 1 - 5");
                m=0;
            }
        }while (m !=5);
    }
    private static void pilih(int p){
        if (p==1) {
            tambah();
        }
        else if (p==2){
            ubah();

        }
        else if (p==3){
            hapus();

        }
        else if (p==4){
            op.tampilData();

        }
    }
    private static void ubah(){
        scn = new Scanner(System.in);
        String noken, merk, type, pabrikan, bbm;
        int tahun, daya, harga;

        try {
            System.out.println("Ubah Data\n");
            System.out.print("Nomor Kendaraan : ");
            noken = scn.nextLine();
            System.out.print("Merk            : ");
            merk = scn.nextLine();
            System.out.print("Type            : ");
            type = scn.nextLine();
            System.out.print("Pabrika" +
                    "n        : ");
            pabrikan = scn.nextLine();
            System.out.print("Tahun Perakitan : ");
            tahun = Integer.parseInt(scn.nextLine());
            System.out.print("Daya mesin(CC)  : ");
            daya = Integer.parseInt(scn.nextLine());
            System.out.print("Bahan Bakar     : ");
            bbm = scn.nextLine();
            System.out.print("Harga(Rp.)      : ");
            harga = Integer.parseInt(scn.nextLine());
            op.ubah(new Data(noken, merk, type, pabrikan,  tahun,  daya, bbm, harga));
        }catch (NumberFormatException e){
            System.out.print("Mohon isi form tahun perakitan, daya mesin dan harga dengan angka");
            ubah();
        }
    }
    private static void hapus(){
        scn = new Scanner(System.in);
        String noken, merk = null, type = null, pabrikan = null, bbm = null;
        int tahun = 0, daya = 0, harga = 0;

        System.out.println("Hapus Data\n");
        System.out.print("Nomor Kendaraan : ");
        noken = scn.nextLine();
        op.hapus(new Data(noken, merk, type, pabrikan,  tahun,  daya, bbm, harga));
    }

    private static void tambah(){
        scn = new Scanner(System.in);
        String noken, merk, type, pabrikan, bbm;
        int tahun, daya, harga;

        try {
            System.out.println("Tambah Data\n");
            System.out.print("Nomor Kendaraan : ");
            noken = scn.nextLine();
            System.out.print("Merk            : ");
            merk = scn.nextLine();
            System.out.print("Type            : ");
            type = scn.nextLine();
            System.out.print("Pabrikan        : ");
            pabrikan = scn.nextLine();
            System.out.print("Tahun Perakitan : ");
            tahun = Integer.parseInt(scn.nextLine());
            System.out.print("Daya mesin(CC)  : ");
            daya = Integer.parseInt(scn.nextLine());
            System.out.print("Bahan Bakar     : ");
            bbm = scn.nextLine();
            System.out.print("Harga(Rp.)      : ");
            harga = Integer.parseInt(scn.nextLine());
            op.simpan(new Data(noken, merk, type, pabrikan,  tahun,  daya, bbm, harga));
        }catch (NumberFormatException e){
            System.out.print("Mohon isi form tahun perakitan, daya mesin dan harga dengan angka");
            tambah();
        }
    }

    private static void menu(){
        System.out.println("Aplikasi Olah Data Inventaris Mobil Siti Handayani\n");
        System.out.println("Menu");
        System.out.println("1. Tambah Data");
        System.out.println("2. Ubah Data");
        System.out.println("3. Hapus Data");
        System.out.println("4. Tampilkan Data");
        System.out.println("5. Keluar\n");
        System.out.print("Pilih Menu >");

    }
}
